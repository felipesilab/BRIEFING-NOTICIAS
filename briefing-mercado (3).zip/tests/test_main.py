import json
import sys
import unittest
from datetime import date, datetime, timezone
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import main


class BriefingTests(unittest.TestCase):
    def setUp(self):
        self.portfolio = {
            "as_of": "2026-09-30",
            "holdings": [
                {"id": "tesouro", "name": "Tesouro Selic", "value_brl": 700.0},
                {"id": "btc", "name": "BITH11", "value_brl": 300.0},
            ],
            "risk_factors": [
                {"name": "Juros e Selic", "holding_ids": ["tesouro"], "keywords": ["Selic", "Copom"], "triggers": "Copom e juros."},
                {"name": "Bitcoin", "holding_ids": ["btc"], "keywords": ["Bitcoin", "BITH11"], "triggers": "Regulação e volatilidade."},
            ],
        }

    def test_parse_rss_and_category(self):
        xml = b'''<rss><channel><item><title>Banco Central decide manter juros - InfoMoney</title><link>https://example.com/noticia</link><description><![CDATA[<p>O Copom manteve a taxa Selic.</p>]]></description><pubDate>Tue, 29 Sep 2026 12:00:00 GMT</pubDate><source>InfoMoney</source></item></channel></rss>'''
        class Response:
            def __enter__(self): return self
            def __exit__(self, *args): pass
            def read(self, size): return xml
        with patch.object(main.urllib.request, "urlopen", return_value=Response()):
            stories = main.fetch_feed("https://example.com/rss", "Brasil")
        self.assertEqual(len(stories), 1)
        self.assertEqual(stories[0].category, "Macroeconomia e política")
        self.assertEqual(stories[0].summary, "O Copom manteve a taxa Selic.")
        self.assertEqual(stories[0].source, "InfoMoney")

    def test_selects_yesterday_relevant_news_and_excludes_daily_noise(self):
        now = datetime(2026, 9, 30, 12, tzinfo=timezone.utc)  # 09:00 em Brasília
        yesterday = datetime(2026, 9, 29, 15, tzinfo=timezone.utc)
        relevant = main.Story("Copom decide manter a taxa Selic", "https://a.test", "InfoMoney", "Decisão de política monetária.", yesterday, "Brasil", "Macroeconomia e política")
        noise = main.Story("Ouro sobe 0,1% nesta terça-feira", "https://b.test", "Market Blog", "Cotação diária do ouro.", yesterday, "Global", "Commodities")
        today = main.Story("Banco Central anuncia decisão", "https://c.test", "Reuters", "Nova decisão publicada hoje.", now, "Global", "Macroeconomia e política")
        old = main.Story("Fed anuncia decisão", "https://d.test", "Reuters", "Decisão antiga.", datetime(2026, 9, 27, 12, tzinfo=timezone.utc), "Global", "Macroeconomia e política")
        self.assertEqual(main.select_top([relevant, noise, today, old], now=now, portfolio=self.portfolio), [relevant])

    def test_default_selection_returns_ten_relevant_stories_when_available(self):
        now = datetime(2026, 9, 30, 12, tzinfo=timezone.utc)
        published = datetime(2026, 9, 29, 15, tzinfo=timezone.utc)
        stories = [
            main.Story(
                f"Banco Central anuncia decisão econômica número {index}",
                f"https://example.com/{index}",
                "Reuters",
                "Nova decisão sobre juros e política econômica.",
                published,
                "Global",
                "Macroeconomia e política",
            )
            for index in range(12)
        ]
        selected = main.select_top(stories, now=now, portfolio=self.portfolio)
        self.assertEqual(len(selected), 10)

    def test_portfolio_risk_matrix_sums_values_with_overlap(self):
        matrix = main.risk_matrix(self.portfolio)
        self.assertEqual(matrix[0]["amount_brl"], 700.0)
        self.assertAlmostEqual(matrix[0]["share_pct"], 70.0)
        self.assertEqual(matrix[1]["amount_brl"], 300.0)

    def test_email_has_top_story_risk_matrix_and_caveat(self):
        now = datetime(2026, 9, 30, 12, tzinfo=timezone.utc)
        story = main.Story("Copom decide manter a Selic", "https://example.com/fed?a=1&b=2", "InfoMoney", "Decisão publicada.", datetime(2026, 9, 29, 12, tzinfo=timezone.utc), "Brasil", "Macroeconomia e política")
        subject, body = main.render_email([story], [], self.portfolio, now)
        self.assertIn("29/09/2026", subject)
        self.assertIn(story.link, body)
        self.assertIn("Matriz indicativa de exposição", body)
        self.assertIn("Juros e Selic", body)
        self.assertIn("não estima perda", body)
        self.assertIn("Possível canal de impacto", body)

    def test_send_email_uses_configured_recipient(self):
        environ = {
            "GMAIL_ADDRESS": "remetente@gmail.com",
            "GMAIL_APP_PASSWORD": "app-password",
            "EMAIL_TO": "destino@example.com",
        }
        with patch.dict("os.environ", environ, clear=True), patch.object(main.smtplib, "SMTP_SSL") as smtp_class:
            main.send_email("Assunto", "Texto do briefing")
        smtp = smtp_class.return_value.__enter__.return_value
        smtp.login.assert_called_once_with("remetente@gmail.com", "app-password")
        sent_message = smtp.send_message.call_args.args[0]
        self.assertEqual(sent_message["To"], "destino@example.com")
        self.assertEqual(sent_message["From"], "remetente@gmail.com")

    def test_send_email_falls_back_to_sender_if_recipient_blank(self):
        environ = {
            "GMAIL_ADDRESS": "remetente@gmail.com",
            "GMAIL_APP_PASSWORD": "app-password",
            "EMAIL_TO": "   ",
        }
        with patch.dict("os.environ", environ, clear=True), patch.object(main.smtplib, "SMTP_SSL") as smtp_class:
            main.send_email("Assunto", "Texto do briefing")
        sent_message = smtp_class.return_value.__enter__.return_value.send_message.call_args.args[0]
        self.assertEqual(sent_message["To"], "remetente@gmail.com")

    def test_feed_url_uses_preferred_portuguese_locale(self):
        url = main.build_feed_url("site:infomoney.com.br economia", "Brasil", "pt-BR", "BR", "BR:pt-419")
        self.assertIn("hl=pt-BR", url)
        self.assertIn("ceid=BR%3Apt-419", url)


if __name__ == "__main__":
    unittest.main()
